This archive contains the binary output files from a build of Weave.

Download the latest build here: https://github.com/IVPR/Weave-Binaries/zipball/master

If you want the source files instead, go here: http://www.github.com/IVPR/Weave

Installation instructions are available here: http://info.oicweave.org/projects/weave/wiki/Deployment_Guide
